# write in 2017/5/10
# distance between lb and ub divided into 2
#

from functools import partial
import numpy as np
from scipy.spatial.distance import pdist, squareform
from scipy.special import comb, perm
import multiprocessing

def pq():#临时图选择专家的概率
    NP = 400
    k = 100
    q = np.linspace(1,NP,NP)# 1 2 ... 39 40
    pq = np.zeros([k,400])
    addpq = np.zeros([k,1])
    for j in range(1,100):#1 2 3 4 5 6 7 8 9

        d =comb(NP,j+1)
        for i in range(0,j+1):
            pq[j,i]= comb(NP-q[i],j)/d
            addpq[j] = addpq[j] + pq[j, i]
        for i in range(0,k):
            pq[j, i] = pq[j, i]/addpq[j]
    pq[0,0]=0.5
    return pq
def sp_process(kmat, fp, swarmsize, p):#spbest：意外流行粒子的位置,spbest_index意外流行粒子的编号
    #计算意外流行结果sbest
    col_sta = np.sum(kmat, axis=0)
    kmat_inf = kmat
    kmat_inf[kmat_inf == 0] = np.inf
    pbest_val_tmp = np.tile(fp, (swarmsize,1))
    nbest_mat = pbest_val_tmp* kmat_inf
    nbestfitness =np.zeros(swarmsize)
    nbest=np.zeros(swarmsize)
    for i in range(swarmsize):
        nbestfitness[i]= np.min(nbest_mat[i,:])
        nbest[i]=np.argmin(nbest_mat[i,:])
    mp_ans = np.zeros([swarmsize, 1])
    nbest = nbest.astype(int)
    for i in range(swarmsize):
        mp_ans[nbest[i]] = mp_ans[nbest[i]] + 1
    col_sta_tmp = np.tile(col_sta, (swarmsize, 1))
    sp_particle_mat = kmat*col_sta_tmp / swarmsize
    sp_particle_mat[sp_particle_mat == 0] = 1
    sp_particle = np.prod(sp_particle_mat, 1) #每个粒子对自己答案的意外流行程度估计
    other_sp_particle = (1 - sp_particle)/(swarmsize - 1) #对其他的估计
    other_sp_particle_tmp = np.tile(other_sp_particle, (swarmsize, 1)).T
    sp_mat = other_sp_particle_tmp * np.ones([swarmsize,swarmsize])

    for i in range(swarmsize):
        sp_mat[i, nbest[i]] = sp_particle[i]

    exp_ans = np.sum(sp_mat,axis=1)
    sp_ans = np.zeros(swarmsize)
    for i in range(swarmsize):
        sp_ans[i] = mp_ans[i]/ exp_ans[i]

    spbest_index = np.argmax(sp_ans)
    spbest = p[spbest_index,:]
    return spbest,spbest_index
def exp_process_low(swarmsize, pbesttempidx, exp_num, pqn):#计算临时专家矩阵  pqn = pq() exp_num = 5
    porb_mat = np.zeros(swarmsize)
    #num_g：粒子数,pbesttempidx：基于pbest适应值排序的序号,exp_num：专家粒子数,pqn：知名度概率 exp_mat：专家知识矩阵

    for i in range(swarmsize):
        porb_mat[i] = 0.5 * pqn[exp_num, np.where(pbesttempidx == i)]
    porb_mat = np.tile(porb_mat, (swarmsize, 1))
    tempmat = np.random.rand(swarmsize,swarmsize)
    tempmat[tempmat < porb_mat] = 1
    tempmat[tempmat!= 1] = 0
    temp=np.eye(swarmsize)
    exp_mat = np.logical_or(tempmat,temp)
    return exp_mat
def _obj_wrapper(func, args, kwargs, x):
    return func(x, *args, **kwargs)

def pso(func, lb, ub, ieqcons=[], f_ieqcons=None, args=(), kwargs={},
        swarmsize=40,  maxiter=100,
        debug=False, processes=1,
        particle_output=False):
    #pso(myfunc, lb, ub,omega= 0.7298,phip=1.49618,phig=1.49618,maxiter=500,swarmsize= 1000,minstep=1e-20,minfunc=1e-20,debug = True)
    """
    Perform a particle swarm optimization (PSO)
    Parameters
    ==========
    func : function适应度函数
        The function to be minimized
    lb : array
        The lower bounds of the design variable(s)
    ub : array
        The upper bounds of the design variable(s)

    Optional
    ========
    ieqcons : list
        A list of functions of length n such that ieqcons[j](x,*args) >= 0.0 in
        a successfully optimized problem (Default: [])
    f_ieqcons : function
        Returns a 1-D array in which each element must be greater or equal
        to 0.0 in a successfully optimized problem. If f_ieqcons is specified,
        ieqcons is ignored (Default: None)
    args : tuple
        Additional arguments passed to objective and constraint functions
        (Default: empty tuple)
    kwargs : dict
        Additional keyword arguments passed to objective and constraint
        functions (Default: empty dict)
    swarmsize : int
        The number of particles in the swarm (Default: 100)
    omega : scalar
        Particle velocity scaling factor (Default: 0.5)
    phip : scalar
        Scaling factor to search away from the particle's best known position
        (Default: 0.5)
    phig : scalar
        Scaling factor to search away from the swarm's best known position
        (Default: 0.5)
    maxiter : int
        The maximum number of iterations for the swarm to search (Default: 100)
    minstep : scalar
        The minimum stepsize of swarm's best position before the search
        terminates (Default: 1e-8)
    minfunc : scalar
        The minimum change of swarm's best objective value before the search
        terminates (Default: 1e-8)
    debug : boolean
        If True, progress statements will be displayed every iteration
        (Default: False)
    processes : int
        The number of processes to use to evaluate objective function and
        constraints (default: 1)
    particle_output : boolean
        Whether to include the best per-particle position and the objective
        values at those.

    Returns
    =======
    g : array
        The swarm's best known position (optimal design)
    f : scalar
        The objective value at ``g``
    p : array
        The best known position per particle
    pf: arrray
        The objective values at each position in p

    """

    assert len(lb)==len(ub), 'Lower- and upper-bounds must be the same length'
    assert hasattr(func, '__call__'), 'Invalid function handle'
    lb = np.array(lb)
    ub = np.array(ub)
    assert np.all(ub>lb), 'All upper-bound values must be greater than lower-bound values'
    mp_pool = multiprocessing.Pool(6)

    exp_num = 50
    interval = np.abs(ub - lb)
    vhigh = 0.2*interval#限定
    vlow = -vhigh
    initK = 20
    ulkv = 60
    # Initialize objective function
    obj = partial(_obj_wrapper, func, args, kwargs)
    num_g1 = 150  # 粒子群 g1_探索子群 15个粒子  剩下的 25个粒子 是g2_开发子群
    num_g2 = swarmsize - num_g1
    D = len(lb)  # the number of dimensions each particle has
    j = np.linspace(0, 1, swarmsize)  # Learning Probability Curve Pc
    j = j * 10
    Pc = np.ones([D, 1]) * (0.0 + (0.25 * (np.exp(j) - np.exp(j[0]))/(np.exp(j[swarmsize - 1]) - np.exp(j[0]))))
    #CL策略曲线

    ite = np.linspace(1, maxiter, maxiter)
    Weight = 0.99 - ite * 0.79 / maxiter
    c0 = 3 - ite * 1.5 / maxiter  # Acceleration Coefficients
    c1 = 2.5 - ite * 2 / maxiter
    c2 = 0.5 + ite * 2 / maxiter

    # Initialize the particle swarm ############################################
    #S = swarmsize


    x = np.random.rand(swarmsize, D)  # particle positions
    v = np.zeros_like(x)# particle velocities
    fx = np.zeros(swarmsize)  # current particle function values适应度
    p = np.zeros_like(x)  # best particle positions **pbest**
    fp = np.ones(swarmsize)*np.inf  # best particle function values **pbest value**
    g = []  #best swarm position  **gbest**
    fg = np.inf # best swarm position starting value   **gbest value**

    for i in range(swarmsize):  # particle positions
        for j in range(D):
            x[i][j] = np.random.uniform(lb[j],ub[j])
    # Initialize the particle's velocity
    v = vlow + np.random.rand(swarmsize, D)*(vhigh - vlow)#vlow = -vhigh vhigh = np.abs(ub - lb)#限定
    # Calculate objective and constraints for each particle
    fx = np.array(mp_pool.map(obj, x))
    for i in range(swarmsize):

        if fx[i]<fp[i]:
            p[i,:] = x[i,:]
            fp[i] = fx[i]
    # Update swarm's best position
    i_min = np.argmin(fp)
    if fp[i_min] < fg:
        fg = fp[i_min]# best swarm position starting value
        g = p[i_min, :].copy()# best swarm position
    else:
        g = x[0, :].copy()

    pqn = pq()            #临时图选择专家的概率
    # Iterate until termination criterion met ##################################


    update_flag = np.zeros([swarmsize,1])#是否更新
    fri_best = np.ones([swarmsize,D])
    for i in range(swarmsize):
        fri_best[i:]=i

    fri_best_pos = np.zeros([swarmsize,D])
    #CL
    for i in range(num_g1):
        fri_best[i,] = i*np.ones([1,D])
        friend1 = np.ceil((num_g1-1) * np.random.rand(1,D))
        friend2 = np.ceil((num_g1-1)  * np.random.rand(1,D))
        friend1 = friend1.astype(int)
        friend2 = friend2.astype(int)
        friend = (fp[friend1] < fp[friend2])*friend1 + (fp[friend1] >= fp[friend2])* friend2
        toss = np.ceil(np.random.rand(1,D) - Pc[:,i].T)
        if toss.all == np.ones([1,D]).all:
            temp_index = np.arange(0,D)
            np.random.shuffle(temp_index)
            toss[0, temp_index[0]] = 0
        fri_best[i,]=(1 - toss)* friend + toss*fri_best[i]
        for j in range(D):
            temp =fri_best[i, j].astype(int)
            fri_best_pos[i,j] = p[temp, j]
    #group 2 从开发子群中用锦标赛选择方法选择fri_best
    for i in range(num_g1,swarmsize):
        fri_best[i,] = i * np.ones([1, D])
        friend1 = np.ceil((swarmsize-1) * np.random.rand(1, D))
        friend2 = np.ceil((swarmsize-1) * np.random.rand(1, D))
        friend1 = friend1.astype(int)
        friend2 = friend2.astype(int)
        friend = (fp[friend1] < fp[friend2]) * friend1 + (fp[friend1] >= fp[friend2]) * friend2
        toss = np.ceil(np.random.rand(1, D) - Pc[:, i].T)
        if toss.all == np.ones([1, D]).all:
            temp_index = np.arange(0,D)
            np.random.shuffle(temp_index)
            toss[0, temp_index[0]] = 0
        fri_best[i,] = (1 - toss) * friend + toss * fri_best[i]
        for j in range(D):
            temp = fri_best[i, j].astype(int)
            fri_best_pos[i, j] = p[temp, j]
    #初始化连接图，每个节点连向最近的k个节点，有向图。
    Kmat = np.zeros([swarmsize,swarmsize])
    tmp_osld = pdist(x)
    Osld = squareform(tmp_osld)
    KmatB = Osld.flatten()
    kamtindex = np.argsort(KmatB)
    for kmatk in range(swarmsize*swarmsize):
        kmatj = np.floor(kamtindex[kmatk]  / swarmsize)
        kmati = kamtindex[kmatk] - (kmatj) * swarmsize
        kmati = kmati.astype(int)
        kmatj = kmatj.astype(int)
        temp = Kmat[kmati,:].astype(int)
        dui = np.sum(temp,0)
        #duj = sum(Kmat[kmatj,:])
        if (dui < initK):
            Kmat[kmati, kmatj] = 1

    kmat = Kmat #Kmat保存距离方面的知识矩阵，kamt为整个知识拓扑结构。

    spbest,_= sp_process(kmat, fp, swarmsize, p) #计算意外流行结果sbest
    it = 0
    while it <= maxiter-1:

        # group 1   探索子群
        vel_g1 = Weight[it] * v[0:num_g1,:] + (c0[it] * np.random.rand(num_g1, D)*(fri_best_pos[0:num_g1,:]-x[0:num_g1,:]))
        maskl = vel_g1 < vlow
        masku = vel_g1 > vhigh
        vel_g1 = vel_g1 * (~np.logical_or(maskl, masku)) + vlow * maskl + vhigh * masku
        pos_g1 = x[0:num_g1,:]+vel_g1

        #group 2  开发子群
        #fri_best开发子群gbest是两个子群的最佳
        spbest_pos_temp =  np.tile(spbest, (num_g2, 1))

        vel_g2 = Weight[it]*v[num_g1:,:] + (c1[it]*np.random.rand(num_g2, D)*(fri_best_pos[num_g1:,:]- x[num_g1:,:]))+(c2[it] * np.random.rand(num_g2, D) * (spbest_pos_temp - x[num_g1:, :]))
        maskl = vel_g2 < vlow
        masku = vel_g2 > vhigh
        vel_g2 = vel_g2 * (~np.logical_or(maskl, masku)) + vlow * maskl + vhigh * masku
        pos_g2 = x[num_g1:,:]+vel_g2

        x[0:num_g1,:] = pos_g1
        x[num_g1:swarmsize, :]= pos_g2
        v[0:num_g1, :] = vel_g1
        v[num_g1:swarmsize, :] = vel_g2

        # Correct for bound violations限制边界
        maskl = x < lb
        masku = x > ub
        x = x * (~np.logical_or(maskl, masku)) + lb * maskl + ub * masku

        betterarray = np.zeros([swarmsize, 1])
        fx = np.array(mp_pool.map(obj, x))
        for i in range(swarmsize):

            if fx[i] < fp[i]:
                p[i, :] = x[i, :]
                fp[i] = fx[i]
                update_flag[i]=0
                betterarray[i] = 1
            else:
                update_flag[i]=update_flag[i]+1
        #pbesttempval = np.sort(fx)
        pbesttempidx = np.argsort(fx)
        # Store particle's best position (if constraints are satisfied)
        # Compare swarm's best position with global best position
        i_min = np.argmin(fp)
        if fp[i_min] < fg:
            if debug:
                print('New best for swarm at iteration {:}: {:} {:}'\
                    .format(it, p[i_min, :], fp[i_min]))
            g = p[i_min, :].copy()
            fg = fp[i_min]

        #更新fri_best
        for i in range(num_g1):
            if update_flag[i] > 5:
                fri_best[i,:]=i * np.ones([1, D])#% for its own pbest
                friend1 = np.ceil((num_g1-1) * np.random.rand(1, D))
                friend2 = np.ceil((num_g1-1) * np.random.rand(1, D))
                friend1 = friend1.astype(int)
                friend2 = friend2.astype(int)
                friend = (fp[friend1] < fp[friend2]) * friend1 + (fp[friend1] >= fp[friend2]) * friend2
                toss = np.ceil(np.random.rand(1, D) - Pc[:, i].T)
                if toss.all == np.ones([1, D]).all:
                    temp_index = np.arange(0, D)
                    np.random.shuffle(temp_index)
                    toss[0, temp_index[0]] = 0
                fri_best[i,] = (1 - toss) * friend + toss * fri_best[i]
                for j in range(D):
                    temp = fri_best[i, j].astype(int)
                    fri_best_pos[i, j] = p[temp, j]
                update_flag[i] = 0
        for i in range(num_g1, swarmsize):
            if update_flag[i] > 5:
                fri_best[i,] = i * np.ones([1, D])
                friend1 = np.ceil((swarmsize-1) * np.random.rand(1, D))
                friend2 = np.ceil((swarmsize-1) * np.random.rand(1, D))
                friend1 = friend1.astype(int)
                friend2 = friend2.astype(int)
                friend = (fp[friend1] < fp[friend2]) * friend1 + (fp[friend1] >= fp[friend2]) * friend2
                toss = np.ceil(np.random.rand(1, D) - Pc[:, i].T)
                if toss.all == np.ones([1, D]).all:
                    temp_index = np.arange(0, D)
                    np.random.shuffle(temp_index)
                    toss[0, temp_index[0]] = 0
                fri_best[i,] = (1 - toss) * friend + toss * fri_best[i]
                for j in range(D):
                    temp = fri_best[i, j].astype(int)
                    fri_best_pos[i, j] = p[temp, j]
                update_flag[i] = 0
        exp_mat = exp_process_low(swarmsize, pbesttempidx, exp_num, pqn)#计算临时专家矩阵
        swmat = kmat#记录毎代发生变更之前的kmat
        kmat = np.double(np.logical_or(kmat,exp_mat))#本代用于计算sbest的矩阵
        spbest, newneidx = sp_process(kmat, fp, swarmsize, p)
        kmat = np.zeros([swarmsize,swarmsize])
        tmp_osld = pdist(x)
        Osld = squareform(tmp_osld)
        KmatB = Osld.flatten()
        kamtindex = np.argsort(KmatB)
        linkmax = (ulkv * it / maxiter)
        for kmatk in range(swarmsize * swarmsize):
            kmatj = np.floor((kamtindex[kmatk]) / swarmsize)
            kmati = kamtindex[kmatk] - (kmatj) * swarmsize
            kmati = kmati.astype(int)
            kmatj = kmatj.astype(int)
            temp = Kmat[kmati, :].astype(int)
            dui = np.sum(temp, 0)
            # duj = sum(Kmat[kmatj,:])
            if (dui < initK):
                Kmat[kmati, kmatj] = 1
        # Kmat保存距离方面的知识矩阵，kamt为整个知识拓扑结构。

        kmat = Kmat  # 更新小世界网络
        if debug:
            print('Best after iteration {:}: {:} {:}'.format(it, g, fg))

        it += 1
    print('Stopping search: maximum iterations reached --> {:}'.format(maxiter))

    #if not is_feasible(g):
        #print("However, the optimization couldn't find a feasible design. Sorry")
    if particle_output:
        return g, fg, p, fp
    else:
        return g, fg