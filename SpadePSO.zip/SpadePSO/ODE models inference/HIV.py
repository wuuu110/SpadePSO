from scipy import *
from scipy.integrate import odeint
from operator import itemgetter
import matplotlib
matplotlib.use('Agg')
from matplotlib.ticker import FormatStrFormatter
from pylab import *
from itertools import product
import itertools
from numpy import zeros_like
import operator

from SpadePSO import pso

modelsOne = []
modelsTwo = []
modelsThree = []

def ModelsProduct(modelsOne, modelsTwo, modelsThree):
    modelsStepOne = list(product("+-",repeat = 4))
    #（+ + + +）至（- - - -） 16个
    modelsStepThree = [('a','a'),('a','b'),('a','c'),('b','b'),('b','c'),('c','c')]
    #produce modelsOne
    modelsStepTwo = [('b',),('c',)]
    for one in modelsStepOne:
        for two in modelsStepTwo:
            for three in modelsStepThree:
                modelsOne.append(one+two+three)
                #（ + + + + b a a）至（- - - - c c c） 192个

    #produce modelsTwo
    modelsStepTwo = [('a',),('c',)]
    for one in modelsStepOne:
        for two in modelsStepTwo:
            for three in modelsStepThree:
                modelsTwo.append(one+two+three)

    #produce modelsThree
    modelsStepTwo = [('a',),('b',)]
    for one in modelsStepOne:
        for two in modelsStepTwo:
            for three in modelsStepThree:
                modelsThree.append(one+two+three)
    return modelsOne, modelsTwo, modelsThree

modelsOne, modelsTwo,modelsThree = ModelsProduct(modelsOne, modelsTwo, modelsThree)


VarList = ["a","b","c"]
initial_condi = [100, 150, 50000]



dictVar = {'a':0, 'b': 1, 'c': 2}
ops = { "+": operator.add, "-": operator.sub }
t_range = arange(0.0,60.0,1.0)
#0到59

def odeFunc(Y, t, x,dictVar):
    #def diff(y, x):
        #return np.array(x)
    # 上面定义的函数在odeint里面体现的就是dy/dx = x
    if x[-3] == 192:
        temp1 = 191
    else:
        temp1 = int(x[-3])
    if x[-2] == 192:
        temp2 = 191
    else:
        temp2 = int(x[-2])
    if x[-1] == 192:
        temp3 = 191
    else:
        temp3 = int(x[-1])
    modelOne = modelsOne[temp1]
    modelTwo = modelsTwo[temp2]
    modelThree = modelsThree[temp3]
    return GenModel(Y, x, modelOne,modelTwo,modelThree, dictVar)
#dictVar = {'a':0, 'b': 1, 'c': 2}


def GenModel(Y,x,modelOne,modelTwo,modelThree, dictVar):
    dydt = zeros_like(Y)
    #生成一个和Y数组一样大小的全0数组
    #三元微分方程组所以是三个
    #ops = { "+": operator.add, "-": operator.sub }
    # （ + + + + b a a）
    # x是系数  y是参数
    # modelOne[0]是 +或-的符号
    # modelOne[-3]是第四个符号   （ + + + + b a a）   b
    # dictVar[modelOne[-3]]  = 1
    dydt[0] = ops[modelOne[0]](dydt[0],x[0]*Y[0])                      #固定是a
    dydt[0] = ops[modelOne[1]](dydt[0],x[1]*Y[dictVar[modelOne[-3]]]) #b,c中用一个
    dydt[0] = ops[modelOne[2]](dydt[0],x[2]*Y[dictVar[modelOne[-2]]]*Y[dictVar[modelOne[-1]]])#abc排列组合
    dydt[0] = ops[modelOne[3]](dydt[0],x[3])

    dydt[1] = ops[modelTwo[0]](dydt[1],x[4]*Y[1])
    dydt[1] = ops[modelTwo[1]](dydt[1],x[5]*Y[dictVar[modelTwo[-3]]])
    dydt[1] = ops[modelTwo[2]](dydt[1],x[6]*Y[dictVar[modelTwo[-2]]]*Y[dictVar[modelTwo[-1]]])
    dydt[1] = ops[modelTwo[3]](dydt[1],x[7])

    dydt[2] = ops[modelThree[0]](dydt[2],x[8]*Y[2])
    dydt[2] = ops[modelThree[1]](dydt[2],x[9]*Y[dictVar[modelThree[-3]]])
    dydt[2] = ops[modelThree[2]](dydt[2],x[10]*Y[dictVar[modelThree[-2]]]*Y[dictVar[modelThree[-1]]])
    dydt[2] = ops[modelThree[3]](dydt[2],x[11])

    return dydt

def pendulum_equations(w, t):
    T, I, V = w
    dT = 80 - 0.15*T - 0.00002*T*V
    dI = 0.00002*T*V - 0.55*I
    dV = 900*0.55*I - 5.5*V - 0.00002*T*V
    return  dT, dI, dV

result_init = odeint(pendulum_equations, initial_condi, t_range)
result_init[:, 2] = result_init[:, 2] / 100
#大小为【60,3】 t_range是60个时刻 ，HIV是3个方程组
#odeint(odeFunc, initial_condi, t_range, args=(xRand,dictVar))
#odeint()函数是scipy库中一个数值求解微分方程的函数
# initial_condi = [100, 150, 50000]
# t_range = arange(0.0,60.0,1.0)
#odeint()函数需要至少三个变量，第一个是微分方程函数，第二个是微分方程初值，第三个是微分的自变量。
#y = odeint(diff, 0, x)  # 设初值为0 此时y为一个数组，元素为不同x对应的y值



def myfunc(xRand):
    #xRand  = [1,2,3,4]
    result_new = odeint(odeFunc, initial_condi, t_range, args=(xRand,dictVar))
    result_new[:, 2] = result_new[:, 2] / 100
    result_sub = result_new - result_init#result_init是已知方程组的函数
    return sum(result_sub*result_sub)

x = (0.15,0,0.00002,80,
     0.55,0,0.00002,0,
	 5.5,495,0.00002,0,
	 122,98,128)
#3*4个系数 选哪三个式子

lb = [0,0,0,79,
	  0,0,0,0,
	  5,495,0,0,
	  0,0,0]
	  
ub = [1,1,1,81, 
      1,1,1,1,
	  6,496,1,1,
	  192,192,192]
fopt = np.zeros(30)
for i in range(30):
    xopt1, fopt1 = pso(myfunc, lb, ub,maxiter=3750,swarmsize= 400,debug = True)
    fopt[i] = fopt1
    print('The optimum is at:')
    print('    {}'.format(xopt1))
    print('Optimal function value:')
    print('    myfunc: {}'.format(fopt1) )
mean = np.mean(fopt)
std = np.std(fopt)
print('mean:    ',mean)
print('var     ',std)