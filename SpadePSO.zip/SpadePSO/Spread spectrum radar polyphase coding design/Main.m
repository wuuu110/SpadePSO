%%
clc
clear
num_particle = 40;%���ӵ�Ⱥ���ģ
range = [0 2*pi];%x���½�
exp_num=3;
initK=2;
ulkv =6;
dim=20;
allk = initK+ulkv;
for func_num=1:1
    max_FES = 2000000;%��Ӧ����������
    max_iter = max_FES/200;
    for i = 1:30
        i
        [position,value(func_num,i),fitcount(func_num,i),SpadePSO_data(i,:)] = SpadePSO(exp_num,initK,ulkv,num_particle,range,dim,max_iter,max_FES);
    end
end
save(['Kneighbor_leida' num2str(max_iter) 'it_' num2str(dim) 'd.mat']);
