function [ result ] = reador(pos)
len = 78;
n = 20;
m = 39; 
y = zeros(len);
    for i=1:n
        tmp =0;
        for j=i:n
            tmp_cos =0;
            for k=abs(2*i-j-1)+1 : j
                tmp_cos = tmp_cos+pos(k);
            end
            tmp = tmp+ cos(tmp_cos);
        end
        y(2*i-1)=tmp;
    end
    for i=1:n-1
        tmp =0.5;
        for j=i+1 :n
            tmp_cos =0;
            for k=abs(2*i-j)+1 : j
                tmp_cos = tmp_cos+pos(k);
            end
            tmp = tmp+ cos(tmp_cos);
        end
        y(2*i)=tmp;
    end
    for i=1:m
        y(m+i)=-1*y(i);
    end
    result = y(1);
    for i=2:2*m
        result= max(result, y(i));
    end






