% function [position,value,result,Error,mean_r,mean_r1,mean_r2,f,f1,f2,yy,fe]= HCL_Sort_SPPSO_fun_sw(exp_num,num_particle,range,dimension,max_iteration,max_FES,func_num)
function [position,value,fitcount,yy]= Kneighbor_reador(exp_num,initK,ulkv,num_particle,range,dimension,max_iteration,max_FES)

%% ���ò���
feflag=true;
fe=inf;
num_g=num_particle; % ����Ⱥ g1_̽����Ⱥ 15������  ʣ�µ� 25������ ��g2_������Ⱥ
num_g1=15;
num_g2=num_g-num_g1;
picnum=0;
j=0:(1/(num_g-1)):1; % Learning Probability Curve Pc
j=j*10;
Pc=ones(dimension,1)*(0.0+((0.25).*(exp(j)-exp(j(1)))./(exp(j(num_g))-exp(j(1)))));

Weight =0.99-(1:max_iteration)*0.79/max_iteration; % Inertia Weight

K=3-(1:max_iteration)*1.5/max_iteration;% Acceleration Coefficients
c1=2.5-(1:max_iteration)*2/max_iteration;
c2=0.5+(1:max_iteration)*2/max_iteration;

%% ��ʼ��
% Initialization
range_min=range(1)*ones(num_g,dimension); % Range for initial swarm's elements
range_max=range(2)*ones(num_g,dimension);
interval = range_max-range_min;
v_max=interval*0.2;
v_min=-v_max;

% ��ʼ��pos �� vel
pos = range_min+ interval.*rand(num_g,dimension);    %  position
vel =v_min+(v_max-v_min).*rand(num_g,dimension); % velocity


k=0;
fitcount=0;
result_data=zeros(1,max_FES);       % result_data��¼����������е���Ӧ��
result=zeros(1,num_g);      % ��¼ÿ������Ӧ��


for i=1:num_g   % benchmark_func ������Ӧ��
    result(i) = reador(pos(i,:));
    fitcount=fitcount+1;
    result_data(fitcount)=result(i);
end

%�������֮ǰ����ͳ�����ӵķ�ɢ�������Ⱥ�����ԣ���������ûɶ����

%%%


[pqn]= pq(1);%��ʱͼѡ��ר�ҵĸ���

[gbest_val,g_index]=min(result);%gbest

yy(1) = gbest_val;
gbest_pos=pos(g_index,:);       % ������Ⱥ�Ĺ�ͬgbest

pbest_pos=pos;
pbest_val=result;

obj_func_slope=zeros(num_g,1);
fri_best=(1:num_g)'*ones(1,dimension);

%% CL
for i=1:num_g1 % Updateding examplers for; group 1
    fri_best(i,:)=i*ones(1,dimension);
    friend1=ceil(num_g1*rand(1,dimension)); % ceil  ���������ȡ��
    friend2=ceil(num_g1*rand(1,dimension));
    friend=(pbest_val(friend1)<pbest_val(friend2)).*friend1+(pbest_val(friend1)>=pbest_val(friend2)).*friend2;
    toss=ceil(rand(1,dimension)-Pc(:,i)');
    if toss==ones(1,dimension)
        temp_index=randperm(dimension);      % p = randperm(n,k) ����һ�д�1��n�������е�k����������k����Ҳ�ǲ���ͬ��
        toss(1,temp_index(1))=0;
        clear temp_index;  % �����ɾ-����
    end
    fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
    for d=1:dimension
        fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
    end    % ������ѡ��
end

for i=num_g1+1:num_g % Updateding examplers for; group 2       �ӿ�����Ⱥ���ý�����ѡ�񷽷�ѡ��fri_best
    fri_best(i,:)=i*ones(1,dimension);
    friend1=ceil(num_g*rand(1,dimension));
    friend2=ceil(num_g*rand(1,dimension));
    friend=(pbest_val(friend1)<pbest_val(friend2)).*friend1+(pbest_val(friend1)>=pbest_val(friend2)).*friend2;
    toss=ceil(rand(1,dimension)-Pc(:,i)');
    if toss==ones(1,dimension)          % ����ѧϰһ����������  ���ܲ�ѧ
        temp_index=randperm(dimension);
        toss(1,temp_index(1))=0;
        clear temp_index;
    end
    fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
    for d=1:dimension
        fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
    end
end

%% SP��ʼ

%statictopo��ʼ������һ���������ˣ�ÿ�����Ӱ��ձ���������ھӺ����ھ�
Kmat = zeros(num_g);
tmp_osld = pdist(pos);
Osld = squareform(tmp_osld);
KmatB = Osld(:);
[kamtC,kamtindex] = sort(KmatB);


for kmatk = 1:num_g*num_g;
    kmatj = floor((kamtindex(kmatk)-1)/num_g)+1;
    kmati = kamtindex(kmatk)-(kmatj-1)*num_g;
    dui = sum(Kmat(kmati,:));
    duj = sum(Kmat(kmatj,:));
    if((dui<initK) && (duj<initK))
        Kmat(kmati,kmatj)=1;
        Kmat(kmatj,kmati)=1;
    end
end
kmat=Kmat;
%
%netplot(kmat,1,k);  ���������֮ǰ��������ͼ�õ�
% saveas(gcf, ['D:\figure\',num2str(picnum), 'ori.png']);
% hold off;
oldkmat=kmat;

[ spbest ] = sp_process( kmat,pbest_val,num_g,pbest_pos ); %�����������н��sbest

% SPbest end

%% ѭ��
Error = gbest_val;
while  fitcount<=max_FES  %��Ҫѭ�����������С��10^-8���߳��������Ӧ����������������
    
    k=k+1;
    
    %% �����ٶ���λ��
    % group 1   ̽����Ⱥ
    if k>max_iteration
        k=k-1;
    end
    delta_g1=(K(k).*rand(num_g1,dimension).*(fri_best_pos(1:num_g1,:)-pos(1:num_g1,:)));    % ֻѧϰ̽����Ⱥ������ ����ά�ȵ�pbest��fri_best��
    vel_g1=Weight(k)*vel(1:num_g1,:)+delta_g1;
    vel_g1=((vel_g1<v_min(1:num_g1,:)).*v_min(1:num_g1,:))+((vel_g1>v_max(1:num_g1,:)).*v_max(1:num_g1,:))+(((vel_g1<v_max(1:num_g1,:))&(vel_g1>v_min(1:num_g1,:))).*vel_g1);
    pos_g1=pos(1:num_g1,:)+vel_g1;
    
    % group 2  ������Ⱥ
    gbest_pos_temp=repmat(gbest_pos,num_g2,1);          % fri_best  ������Ⱥ       gbest ��������Ⱥ�����
    spbest_pos_temp=repmat(spbest,num_g2,1);
    delta_g2=(c1(k).*rand(num_g2,dimension).*(fri_best_pos(num_g1+1:end,:)-pos(num_g1+1:end,:)))+(c2(k).*rand(num_g2,dimension).*(spbest_pos_temp-pos(num_g1+1:end,:)));
    vel_g2=Weight(k)*vel(num_g1+1:end,:)+delta_g2;
    vel_g2=((vel_g2<v_min(num_g1+1:end,:)).*v_min(num_g1+1:end,:))+((vel_g2>v_max(num_g1+1:end,:)).*v_max(num_g1+1:end,:))+(((vel_g2<v_max(num_g1+1:end,:))&(vel_g2>v_min(num_g1+1:end,:))).*vel_g2);
    pos_g2=pos(num_g1+1:end,:)+vel_g2;
    
    % whole group
    
    pos=[pos_g1;pos_g2];
    vel=[vel_g1;vel_g2];
    
    
    %% ������Ӧ�� && ���� pbest gbest
    % Evaluate fitness
    betterarray=zeros(num_g,1);
    for i=1:num_g
        if (sum(pos(i,:)>range_max(i,:))+sum(pos(i,:)<range_min(i,:))==0)
            %                 result(i)=benchmark_func(pos(i,:),func_num);
            result(i) = reador(pos(i,:));
            result_data(fitcount)=result(i);
            fitcount=fitcount+1;
            if fitcount>=max_FES
                break;
            end
            %         else
            %             pos(i,:)=range_min(1,:)+ interval(1,:).*rand(1,dimension);
            %             result(i) = feval(fhd,pos(i,:)',func_num);
            %             result_data(fitcount)=result(i);
            %             fitcount=fitcount+1;
            %             if fitcount>=max_FES
            %                 break;
            %             end
        end
        if  result(i)<pbest_val(i) % update pbest value and position
            pbest_pos(i,:)=pos(i,:);
            pbest_val(i)=result(i);
            obj_func_slope(i)=0;
            betterarray(i)=1;
        else
            obj_func_slope(i)=obj_func_slope(i)+1;
        end
        
        if  pbest_val(i)<gbest_val % update gbest value and postion
            gbest_pos=pbest_pos(i,:);
            gbest_val=pbest_val(i);
        end
    end
    
    [pbesttempval, pbesttempidx]=sort(result);
    %% ��¼gbest�Ĺ���
    yy(k) = gbest_val;

    %% ���� fri_best
    for i=1:num_g1 % updateding exampler for group 1
        if obj_func_slope(i)>5
            fri_best(i,:)=i*ones(1,dimension); % for its own pbest
            friend1=ceil(num_g1*rand(1,dimension));
            friend2=ceil(num_g1*rand(1,dimension));
            friend=(pbest_val(friend1)<pbest_val(friend2)).*friend1+(pbest_val(friend1)>=pbest_val(friend2)).*friend2;
            toss=ceil(rand(1,dimension)-Pc(:,i)');
            
            if toss==ones(1,dimension)
                temp_index=randperm(dimension);
                toss(1,temp_index(1))=0;
                clear temp_index;
            end
            
            fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
            for d=1:dimension
                fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
            end
            obj_func_slope(i)=0;
        end
    end % updating exampler for group 1
    
    for i=num_g1+1:num_g % updating exampler for group 2
        if obj_func_slope(i)>5
            fri_best(i,:)=i*ones(1,dimension);
            friend1=ceil(num_g*rand(1,dimension));
            friend2=ceil(num_g*rand(1,dimension));
            friend=(pbest_val(friend1)<pbest_val(friend2)).*friend1+(pbest_val(friend1)>=pbest_val(friend2)).*friend2;
            toss=ceil(rand(1,dimension)-Pc(:,i)');
            
            if toss==ones(1,dimension)
                temp_index=randperm(dimension);
                toss(1,temp_index(1))=0;
                clear temp_index;
            end
            
            fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
            for d=1:dimension
                fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
            end
            obj_func_slope(i)=0;
        end
    end % updating exampler for group 2
    
    %% ����SP
    [ exp_mat ] = exp_process_low( num_g,pbesttempidx,exp_num,pqn );%������ʱר�Ҿ���
    swmat=kmat;%��¼�����������֮ǰ��kmat
    
    if mod(k,15)==0||picnum==1
       % netplot(exp_mat,1,k);
%        saveas(gcf, ['D:\figure\',num2str(picnum), 'exp.png']);
   %     hold off;
%        netplot(swmat,1,k);
 %       saveas(gcf, ['D:\figure\',num2str(picnum), 'swmat.png']);
 %       hold off;
    end
    kmat=double(kmat|exp_mat);%�������ڼ���sbest�ľ���
    
    if mod(k,15)==0||picnum==1
   %     netplot(kmat,1,k);
   %     saveas(gcf, ['D:\figure\',num2str(picnum), 'kmat_exp_mat.png']);
    %    hold off;
    end
    [ spbest,newneidx ] = sp_process( kmat,pbest_val,num_g,pbest_pos );%���㱾��sbest
   %�������������ھӾ���
    Kmat = zeros(num_g);
tmp_osld = pdist(pos);
Osld = squareform(tmp_osld);
KmatB = Osld(:);
[kamtC,kamtindex] = sort(KmatB);

linkmax=initK+(ulkv*k/max_iteration);
for kmatk = 1:num_g*num_g;
    kmatj = floor((kamtindex(kmatk)-1)/num_g)+1;
    kmati = kamtindex(kmatk)-(kmatj-1)*num_g;
    dui = sum(Kmat(kmati,:));
    duj = sum(Kmat(kmatj,:));
    if((dui<linkmax) && (duj<linkmax))
        Kmat(kmati,kmatj)=1;
        Kmat(kmatj,kmati)=1;
    end
end

    kmat=Kmat;%����С��������
    if mod(k,15)==0||picnum==1
%     netplot(kmat);
%     saveas(gcf, ['D:\figure\',num2str(picnum), 'swmat_newneimat.png']);
%     hold off;
    end
    % SPEND
    %%
    Error = gbest_val ;
    if fitcount>=max_FES 
        break;
    end
    
    
    if mod(k,15)==0||picnum==1% && (~isequal(kmat, oldkmat))
        
      %  netplot(kmat,1,k);
  %      saveas(gcf, ['D:\figure\',num2str(picnum), '.png']);
      %  hold off;
        oldkmat=kmat;
        picnum=picnum+1;
    end
    
    
end
%% ������
position=pos;
value=gbest_val;
result = yy;
Error = value;
end


function netplot(G)
    n = size(G, 1);
    [x y] = pol2cart((0:n-1)*2*pi/n, 1);
    gplot(G, [x' y'], '-o');
end



function netplot1(G)
    
    n1 = 15;
    [x1 y1] = pol2cart((0:n1-1)*2*pi/n1, 1);
    n2 = 25;
    [x2 y2] = pol2cart((0:n2-1)*2*pi/n2, 2);
    x= [x1 x2];
    y= [y1 y2];
    
  
    gplot(G, [x' y'], '-bo');
      hold on;
    plot(x1,y1,'ro')
end