function [f,f1,f2]= Diversity(pos,D,ps)
% [f,f1,f2]= Diversity(posall(i,j,:,:,:),sortall(i,j,:,:),iter_max,D,pop_size);

num_g1=15;
num_g2=25;
xbdt=zeros(ps,D);
xbdt=repmat(sum(pos,1)/ps,ps,1);
a=pos-xbdt;
b=a.^2;
c=sum(b,2);
d=c.^0.5;
e=sum(d);
f=e/ps;

xbdt1=zeros(num_g1,D);
xbdt1=repmat(sum(pos(1:num_g1,:),1)/(num_g1),num_g1,1);
a=pos(1:num_g1,:)-xbdt1;
b=a.^2;
c=sum(b,2);
d=c.^0.5;
e=sum(d);
f1=e/(num_g1);

xbdt2=zeros(num_g2,D);
xbdt2=repmat(sum(pos(num_g1+1:ps,:),1)/(num_g2),num_g2,1);
a=pos(num_g1+1:ps,:)-xbdt2;
b=a.^2;
c=sum(b,2);
d=c.^0.5;
e=sum(d);
f2=e/(num_g2);

end






