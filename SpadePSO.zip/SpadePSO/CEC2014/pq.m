function [pq]= pq(q)
%�����ǰ��չ�ʽ25���ɵ�һ�Ѹ���ֵ
NP=40;
k=10;
q=1:NP;
pq=zeros(k,length(q));
addpq=zeros(k,1);
for j=2:10
    d=nchoosek(NP,j);
for i=1:j
pq(j,i)=nchoosek(NP-q(i),j-1)/d;

addpq(j)=addpq(j)+pq(j,i);

end
for i=1:k
pq(j,i)=pq(j,i)/addpq(j);
end
% plot(pq(j,1:j));
% hold on;
end
% legend('top2','top3','top4','top5','top6','top7','top8','top9','top10');
% xlabel('sort index');
% ylabel('prob');
% title('The probability of visible');

pq(1,1)=0.5;
end

